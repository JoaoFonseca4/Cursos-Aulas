import Pagina from '@/components/template/Pagina'

export default function Home() {
    return (
        <Pagina>
            <div>
                <h1 className="text-2xl font-bold">Seja Bem Vindo!!!</h1>
            </div>
        </Pagina>
    )
}
