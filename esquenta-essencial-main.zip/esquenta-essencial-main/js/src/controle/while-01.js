let numero = 1;

while (numero <= 5) {
    console.log('Código foi executado!');
    numero++;
}

for (let numero = 1; numero <= 5; numero++) {
    console.log('Código foi executado!');
}
