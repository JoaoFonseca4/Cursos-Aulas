let fome = true;
let boloMagico = false;

if (fome && boloMagico) {
    console.log('O herói come o bolo mágico e ganha superpoderes!');
} else {
    console.log('O herói decide não comer o bolo... e continua a jornada.');
}
