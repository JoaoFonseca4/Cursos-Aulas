let expressao = true;

if (expressao) {
    console.log('A condição é verdadeira!');
    console.log('O código dentro do bloco é executado!');
}

console.log('Fim');
