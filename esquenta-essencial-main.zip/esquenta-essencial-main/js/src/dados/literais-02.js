console.log(123); // number
console.log(15.5); // number
console.log('Olá, mundo!'); // string
console.log(true); // boolean
