const nome = 'Lucas';
const idade = 25;
const cidade = 'São Paulo';

// const frase = 'Olá! Meu nome é ' + nome + ', tenho ' + idade + 'anos e moro em ' + cidade + '.';
const frase = `Olá! Meu nome é ${nome}, tenho ${idade} anos e moro em ${cidade}.`;
console.log(frase);
