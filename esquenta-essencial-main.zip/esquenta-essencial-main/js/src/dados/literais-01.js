123;
15.5;
('Olá, mundo!');
true;
