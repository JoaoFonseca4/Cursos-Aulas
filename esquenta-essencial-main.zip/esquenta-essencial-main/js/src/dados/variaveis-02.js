const x = 10;
const y = 20;

const resultadoDaSoma = x + y;

console.log(resultadoDaSoma);

const xAlterado = x + 10;
console.log(x, xAlterado, y);
