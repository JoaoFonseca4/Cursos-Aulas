let x = 10;
let y = 20;

console.log(x + y);

x = x + 10;
console.log(x + y);

console.log(x, y);
