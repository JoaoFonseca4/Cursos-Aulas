function saudacao() {
    console.log('Olá!');
    console.log('Tudo bem?');
}

saudacao();
saudacao();

function saudacaoPara(nome) {
    console.log(`Olá, ${nome}!`);
}

saudacaoPara('Lucas');
saudacaoPara('Maria');
saudacaoPara('José');
saudacaoPara('Ana');
