function soma(a, b) {
    return a + b;
}

const resultado = soma(2, 3);
console.log(resultado * 2);
