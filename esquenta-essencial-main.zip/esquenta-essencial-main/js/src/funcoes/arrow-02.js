const dobro = (arr) => arr.map((n) => n * 2);

console.log(dobro([1, 2, 3, 4]));
