const soma = (a, b) => a + b;

console.log(soma(5, 3));
