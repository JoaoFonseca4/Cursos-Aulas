SELECT * FROM cliente;

UPDATE cliente SET salario = 4000 WHERE id = 1;

UPDATE cliente SET administrador = FALSE WHERE id = 2;

UPDATE cliente SET nome = 'Lia', pontos = 0 WHERE id = 2;