CREATE DATABASE esquenta; 

SHOW DATABASES;

DROP DATABASE esquenta;

USE esquenta;


