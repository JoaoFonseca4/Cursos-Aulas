import Pagina from '@/components/template/Pagina'

export default function Home() {
    return (
        <Pagina>
            <h1>Seja bem vindo(a)!</h1>
        </Pagina>
    )
}
