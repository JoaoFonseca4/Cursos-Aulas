export default function PaginaAdmin() {
    return (
        <div className="flex flex-col gap-6">
            <h1 className="text-2xl font-black">Administração</h1>
            <p>Esta é a página de administração.</p>
        </div>
    )
}
