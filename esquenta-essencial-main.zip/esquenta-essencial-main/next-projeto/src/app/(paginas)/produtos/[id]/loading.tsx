import Carregando from '@/components/shared/Carregando'

export default function PaginaCarregando() {
    return <Carregando quantidade={1} />
}
