let id: string | number = 5;
console.log(id);

id = 'f4a460f0-0b3b-4b3b-8b3b-0b3b4b3b8b3b';
console.log(id);
