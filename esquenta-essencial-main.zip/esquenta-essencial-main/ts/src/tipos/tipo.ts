type ID = string | number;

let usuarioId: ID = 2112;
console.log(usuarioId);

usuarioId = 'a1b2c3d4-0b3b-4b3b-8b3b-0b3b4b3b8b3b';
console.log(usuarioId);
