let valor = 30;
console.log(valor);

// valor = 'João';
console.log(valor);
