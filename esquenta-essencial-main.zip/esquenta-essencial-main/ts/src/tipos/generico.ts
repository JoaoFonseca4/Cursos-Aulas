let x: any = 5;
console.log(x);

x = 'João';
console.log(x);

x = [1, 2, 3, 4];
console.log(x);
