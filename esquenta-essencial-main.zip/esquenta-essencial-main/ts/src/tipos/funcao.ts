function bomDia(): void {
    console.log('Bom dia!');
}

bomDia();

function somar(a: number, b: number): number {
    return a + b;
}

const resultado = somar(10, 20);
console.log(resultado);
