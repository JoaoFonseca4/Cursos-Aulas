let nome: string = 'João';
let numeros: number[] = [1, 2, 3, 4];

console.log(nome);
console.log(numeros);

export {};
