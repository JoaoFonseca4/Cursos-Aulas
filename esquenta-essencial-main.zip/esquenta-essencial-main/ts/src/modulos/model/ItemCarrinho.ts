export default interface ItemCarrinho {
    nome: string;
    preco: number;
    quantidade: number;
}
