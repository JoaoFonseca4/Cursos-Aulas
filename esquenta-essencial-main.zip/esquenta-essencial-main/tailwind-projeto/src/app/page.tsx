import Pagina from '@/components/template/Pagina'

export default function Home() {
    return (
        <Pagina>
            <div>Início</div>
            <button className="botao vermelho">Salvar</button>
        </Pagina>
    )
}
