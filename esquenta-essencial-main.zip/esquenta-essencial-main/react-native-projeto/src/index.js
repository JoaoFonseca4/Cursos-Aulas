import { registerRootComponent } from 'expo'
import App from './screens/drawer'

registerRootComponent(App)
